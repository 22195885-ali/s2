<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap test</title>
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
  </head>
  <body>
    <h1 class="text-success">Hello, world!</h1>

    <script src="assets/js/bootstrap.bundle.min.js"></script>
  </body>
</html>
