<?php include '../../_layout/userlayout/header.php'; ?>
<!-- İçerik -->
<?php include '../../_layout/userlayout/footer.php'; ?>
