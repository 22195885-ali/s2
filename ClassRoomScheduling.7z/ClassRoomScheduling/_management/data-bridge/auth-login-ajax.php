<?php
require_once '../Sc.php';

if ($_POST) {
    $sc = new Sc();

    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $repassword = $_POST['repassword'] ?? '';

    if ($password !== $repassword) {
        $sc->jsonResponse('error', 'Şifreler uyuşmuyor.');
    }

    $response = $sc->callApi('POST', 'http://localhost/room-scheduler/api/create-user.php', [
        'name' => $name,
        'email' => $email,
        'password' => $password
    ], [], false);

    if ($response['status'] === 'success') {
        $sc->jsonResponse('success', 'Kayıt başarılı! Giriş yapabilirsiniz.');
    } else {
        $sc->jsonResponse('error', $response['message'] ?? 'Kayıt başarısız.');
    }
}
