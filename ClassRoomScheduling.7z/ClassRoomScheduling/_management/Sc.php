<?php

class Sc
{
    public function getRouteInfo()
    {
        $url = $_SERVER['REQUEST_URI'];
        $parts = explode('/', trim($url, '/'));

        $pagesIndex = array_search('Pages', $parts);

        $module = isset($parts[$pagesIndex + 1]) ? $parts[$pagesIndex + 1] : null;
        $page = isset($parts[$pagesIndex + 2]) ? pathinfo($parts[$pagesIndex + 2], PATHINFO_FILENAME) : null;

        return [
            'module' => $module,
            'page' => $page
        ];
    }

    public function callApi(string $method, string $url, array $data = [], array $headers = [], bool $useToken = true): array
    {
        $method = strtoupper($method);
        $ch = curl_init();

        if ($method === 'GET' && !empty($data)) {
            $url .= '?' . http_build_query($data);
        } elseif (in_array($method, ['POST', 'PUT', 'DELETE'])) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        }

        $defaultHeaders = [
            'Content-Type: application/x-www-form-urlencoded'
        ];

        if ($useToken && isset($_SESSION['auth']['token'])) {
            $defaultHeaders[] = 'Authorization: Bearer ' . $_SESSION['auth']['token'];
        }

        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_HTTPHEADER => array_merge($defaultHeaders, $headers)
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error || !$response) {
            return [
                'status' => 'error',
                'message' => 'Bağlantı hatası: ' . $error
            ];
        }

        $json = json_decode($response, true);
        if (!is_array($json)) {
            return [
                'status' => 'error',
                'message' => 'Geçersiz JSON yanıtı'
            ];
        }

        return $json + ['http_code' => $httpCode];
    }

    public function login(string $email, string $password, string $loginEndpoint)
    {
        session_start();

        $email = trim($email);
        $password = trim($password);

        if (!$email || !$password) {
            return $this->jsonResponse('error', 'Email veya şifre eksik.');
        }

        $response = $this->callApi('POST', $loginEndpoint, [
            'email' => $email,
            'password' => $password
        ], [], false); // Token gönderme

        if (!isset($response['status']) || $response['status'] !== 'success') {
            return $this->jsonResponse('error', $response['message'] ?? 'Giriş başarısız.');
        }

        $_SESSION['auth'] = [
            'name' => $response['name'] ?? null,
            'email' => $response['email'] ?? $email,
            'userType' => $response['userType'] ?? 'user',
            'token' => $response['token'] ?? null
        ];

        return $this->jsonResponse('success', $response['message'] ?? 'Giriş başarılı.', [
            'redirect' => $response['redirect'] ?? 'Pages/User/Home.php'
        ]);
    }

    private function jsonResponse(string $status, string $message, array $extra = [])
    {
        header('Content-Type: application/json');
        echo json_encode(array_merge([
            'status' => $status,
            'message' => $message
        ], $extra));
        exit;
    }
}
