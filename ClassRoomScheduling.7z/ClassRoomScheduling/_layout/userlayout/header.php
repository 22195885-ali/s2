<?php
include '../../_management/Sc.php';
$sc = new Sc();
$route = $sc->getRouteInfo();
$modul = $route['module'];
$page  = $route['page'];
?>

<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>ClassroomScheduling | <?= ucfirst($modul) . ' - ' . ucfirst($page) ?></title>

  <!-- Titillium Web -->
  <link href="https://fonts.googleapis.com/css2?family=Titillium+Web:wght@400;700&display=swap" rel="stylesheet">
  
  <!-- Bootstrap ve Custom CSS -->
  <link href="../../assets/css/bootstrap.min.css" rel="stylesheet">
  <link href="../../assets/css/custom.css" rel="stylesheet">
</head>
<body>
