  <!-- JQuery ve SweetAlert -->
  <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

  <!-- Engine -->
  <script id="engine" 
          src="../../assets/js/engine.js" 
          data-module="<?= $route['module'] ?>" 
          data-page="<?= $route['page'] ?>"></script>
</body>
</html>
