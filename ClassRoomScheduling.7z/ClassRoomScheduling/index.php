<?php
header('Location: Auth/Sign-in.php');
exit;
?>
