const Engine = {};

Engine.init = function () {
    const module = this.getModul().split(',');

    for (let i = 0; i < module.length; i++) {
        this.runModule(module[i]);
    }
};

Engine.getModul = function () {
    const scripts = document.getElementById('engine');
    return scripts.getAttribute("data-module");
};

Engine.getPage = function () {
    const scripts = document.getElementById('engine');
    return scripts.getAttribute("data-page");
};

Engine.runModule = function (module) {
    const page = this.getPage();

    switch (module) {
        case "Admin":
            switch (page) {
                case "Home":
                    this.AdminHome();
                    break;
                // örnek: case "Rooms": this.AdminRooms(); break;
                default:
                    break;
            }
            break;

        case "User":
            switch (page) {
                case "Home":
                    this.UserHome();
                    break;
                // örnek: case "Rooms": this.UserRooms(); break;
                default:
                    break;
            }
            break;

        default:
            break;
    }
};

// Örnek metodlar
Engine.AdminHome = function () {
    console.log("Admin/Home yüklendi");
};

Engine.UserHome = function () {
    console.log("User/Home yüklendi");
};

// Sayfa yüklendiğinde çalıştır
window.addEventListener("DOMContentLoaded", function () {
    Engine.init();
});
