$(document).ready(function () {
    // GİRİŞ FORMU
    $('#sign-in-form').on('submit', function (e) {
        e.preventDefault();
        const form = this;
        const url = form.action;

        const formData = {
            email: form.email.value,
            password: form.password.value
        };

        $.ajax({
            url: url,
            method: 'POST',
            data: formData,
            dataType: 'json',
            success: function (response) {
                if (response.status === 'success') {
                    Swal.fire({
                        icon: 'success',
                        title: 'Giriş Başarılı',
                        text: response.message,
                        confirmButtonText: 'Tamam'
                    }).then(() => {
                        window.location.href = response.redirect || 'Pages/User/Home.php';
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Hata',
                        text: response.message || 'Giriş başarısız.'
                    });
                }
            },
            error: function (xhr) {
                Swal.fire({
                    icon: 'error',
                    title: 'Sunucu Hatası',
                    text: xhr.responseJSON?.message || 'Bir şeyler ters gitti.'
                });
            }
        });
    });

    // KAYIT FORMU
    $('#register-form').on('submit', function (e) {
        e.preventDefault();
        const form = this;

        const formData = {
            name: form.name.value,
            email: form.email.value,
            password: form.password.value,
            repassword: form.repassword.value
        };

        $.ajax({
            url: '../_management/data-bridge/auth-register-ajax.php',
            method: 'POST',
            data: formData,
            dataType: 'json',
            success: function (response) {
                if (response.status === 'success') {
                    Swal.fire({
                        icon: 'success',
                        title: 'Kayıt Başarılı',
                        text: response.message,
                        confirmButtonText: 'Giriş Yap'
                    }).then(() => {
                        window.location.href = 'Sign-in.php';
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Hata',
                        text: response.message
                    });
                }
            },
            error: function (xhr) {
                Swal.fire({
                    icon: 'error',
                    title: 'Sunucu Hatası',
                    text: xhr.responseJSON?.message || 'Bir hata oluştu.'
                });
            }
        });
    });
});
