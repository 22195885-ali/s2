<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <title>🪐 Uzay Gemisine Katıl</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Font, Bootstrap, CSS -->
  <link href="https://fonts.googleapis.com/css2?family=Titillium+Web:wght@400;700&display=swap" rel="stylesheet">
  <link href="../assets/css/bootstrap.min.css" rel="stylesheet">
  <link href="../assets/css/custom.css" rel="stylesheet">
</head>
<body>
  <main class="form-signin w-100 m-auto">
    <form id="register-form">
      <h1 class="h3 mb-3 fw-normal text-center">🪐 Uzay Gemisine Katıl</h1>

      <div class="mb-3">
        <label for="name" class="form-label">🧑‍🚀 Mürettebat Adınız</label>
        <input type="text" class="form-control" id="name" placeholder="Galaktik adınız" required>
      </div>

      <div class="mb-3">
        <label for="email" class="form-label">🌍 Dünya Kimliğiniz (E-posta)</label>
        <input type="email" class="form-control" id="email" placeholder="ornek@galaksi.org" required>
      </div>

      <div class="mb-3">
        <label for="password" class="form-label">🛰️ Giriş Kodunuz (Şifre)</label>
        <input type="password" class="form-control" id="password" placeholder="Şifreniz" required>
      </div>

      <div class="mb-3">
        <label for="repassword" class="form-label">🔁 Şifre Tekrar</label>
        <input type="password" class="form-control" id="repassword" placeholder="Şifrenizi tekrar yazınız" required>
      </div>

      <button class="w-100 btn btn-lg space-btn" type="submit">🪐 Kayıt Ol ve Fırlat</button>

      <p class="mt-5 mb-3 text-muted text-center">☄️ Uzay Komutanlığı 2025</p>

      <div class="text-center mt-3">
        <a href="Sign-in.php" class="btn btn-sm btn-outline-light">🚀 Zaten Mürettebatım? Giriş Yap</a>
      </div>
    </form>
  </main>

  <!-- JS -->
  <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

  <script>
    $('#register-form').on('submit', function(e) {
      e.preventDefault();

      const name = $('#name').val().trim();
      const email = $('#email').val().trim();
      const password = $('#password').val();
      const repassword = $('#repassword').val();

      if (!name || !email || !password || !repassword) {
        Swal.fire('Eksik Bilgi', 'Lütfen tüm alanları doldurunuz.', 'warning');
        return;
      }

      if (password !== repassword) {
        Swal.fire('Uyarı', 'Şifreler uyuşmuyor.', 'error');
        return;
      }

      $.ajax({
        url: 'http://localhost/room-scheduler/api/register-lecturer.php',
        method: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({ name, email, password }),
        dataType: 'json',
        success: function (response) {
          Swal.fire({
            icon: 'success',
            title: 'Kayıt Başarılı',
            text: response.message || 'Başarıyla kaydoldunuz.'
          }).then(() => {
            window.location.href = 'Sign-in.php';
          });
        },
        error: function (xhr) {
          const msg = xhr.responseJSON?.message || 'Bir şeyler ters gitti.';
          Swal.fire('Sunucu Hatası', msg, 'error');
        }
      });
    });
  </script>
</body>
</html>
